module.exports = async function HandleError(context, props) {
    console.error(props.error);
    // or you can choose not to reply any error messages
    await context.sendText(
      '發生了一些意外錯誤。 請稍後重試，不便之處，敬請原諒。'
    );
    if (process.env.NODE_ENV === 'production') {
      // send your error to your error tracker, for example: Sentry
    }
    if (process.env.NODE_ENV === 'development') {
      await context.sendText(props.error.stack);
    }
  };