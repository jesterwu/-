module.exports = {
    session: {
      driver: 'file',
      stores: {
        file: {
          dirname: '.sessions'
        }
      }
    },
    initialState: {
    },
    channels: {
      line: {
        enabled: true,
        path: '/webhooks/line',
        // sendMethod can be either "push" or "reply"
        sendMethod: 'push',
        accessToken: process.env.LINE_ACCESS_TOKEN,
        channelSecret: process.env.LINE_CHANNEL_SECRET
      }
    }
  }